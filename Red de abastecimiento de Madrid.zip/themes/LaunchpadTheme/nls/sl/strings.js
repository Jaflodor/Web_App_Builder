define({
  "_themeLabel": "Zagonska vrstica",
  "_layout_default": "Privzeta postavitev",
  "_layout_right": "Desna postavitev"
});