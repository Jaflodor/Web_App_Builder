define({
  "_widgetLabel": "Balkbediening verankeren",
  "_layout_default": "Standaardlay-out",
  "_layout_layout1": "Lay-out 0",
  "more": "Meer widgets"
});