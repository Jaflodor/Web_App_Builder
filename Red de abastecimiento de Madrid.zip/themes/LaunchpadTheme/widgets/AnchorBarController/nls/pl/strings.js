define({
  "_widgetLabel": "Kontroler paska zakotwiczenia",
  "_layout_default": "Kompozycja domyślna",
  "_layout_layout1": "Układ 0",
  "more": "Więcej widżetów"
});