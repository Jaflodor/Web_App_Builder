define({
  "_widgetLabel": "Fiksuoti juostos valdiklį",
  "_layout_default": "Numatytasis maketas",
  "_layout_layout1": "0 išdėstymas",
  "more": "Daugiau valdiklių"
});